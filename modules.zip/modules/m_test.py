# import m

# from m import hello , hi
# from n import hello as h
# from m import *
from m import hello, hi, name 
hello()
hi()
# h()
print(name)