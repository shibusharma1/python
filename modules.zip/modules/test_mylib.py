import mylib


#testing math utiities

result_add =mylib.add(10,20)
print(f"Add:{result_add}")

result_subtract =mylib.subtract(20,10)
print(f"Subtrast:{result_subtract}")

#testing string utilities

result_uppercase=mylib.uppercase("hello")
print(f"Uppercase: {result_uppercase}")


result_lowercase=mylib.lowercase("WORLD")
print(f"lowercase: {result_lowercase}")