def uppercase(s):
    """Return the uppercase version of a string."""
    return s.upper()

def lowercase(s):
    """Return the lowercase version of a string."""
    return s.lower()