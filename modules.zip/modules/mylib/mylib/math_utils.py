def add(a,b):
    """Retun the sum of two number."""
    return a+b

def subtract(a,b):
    """Retun the difference of two number."""
    return a-b