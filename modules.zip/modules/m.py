#creating a simple module in python
__all__ = ['name','hello'] #it is only for from  m import *
name="Ram"

def hello():
    print("Hello")

def hi():
    print("Hi")

# print(dir())  