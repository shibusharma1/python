
name="Ram"

def hello():
    print("Hello")

def hi():
    print("Hi")